#!/usr/bin/env python3

import merge
merge.main()